import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProfileSection } from "@/components/ProfileSection";
import { ProjectCard } from "@/components/ProjectCard";
import { WorkExperience } from "@/components/WorkExperience";
import { Certifications } from "@/components/Certifications";
import { SkillsSection } from "@/components/SkillsSection";
import { Education } from "@/components/Education";
import { Services } from "@/components/Services";
import { ContactForm } from "@/components/ContactForm";
import { Testimonials } from "@/components/Testimonials";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { ExpandedDialog } from "@/components/ui/dialog-content";
import { useState } from "react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { 
  GraduationCap, 
  Award, 
  Quote, 
  Code, 
  Briefcase, 
  Wrench, 
  Brain, 
  MailIcon 
} from "lucide-react";

const projects = [
  {
    title: "Digital Transformation Initiative",
    description: "Led a team of 15 in modernizing legacy systems for a Fortune 500 company.",
    tags: ["Digital Transformation", "Change Management", "Enterprise"],
    image: "/photo-1486312338219-ce68d2c6f44d",
    companyLogo: "/company-logo-1.png",
  },
  {
    title: "Agile Implementation",
    description: "Successfully transitioned a 50-person development team to Agile methodology.",
    tags: ["Agile", "Scrum", "Team Leadership"],
    image: "/photo-1519389950473-47ba0277781c",
  },
  {
    title: "E-commerce Platform Launch",
    description: "Managed the development and launch of a scalable e-commerce platform.",
    tags: ["E-commerce", "Project Management", "Tech"],
    image: "/photo-1531297484001-80022131f5a1",
  },
];

const Index = () => {
  const [showAllProjects, setShowAllProjects] = useState(false);
  const projectsPlugin = Autoplay({ delay: 3000, stopOnInteraction: false });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <ProfileSection />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16 py-16">
            <section id="projects" className="rounded-xl">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2 justify-start md:justify-center mx-auto">
                  <Code className="w-6 h-6" />
                  <h2 className="text-2xl md:text-3xl font-bold">Featured Projects</h2>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setShowAllProjects(true)}
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" /> Show All
                </Button>
              </div>
              <Carousel
                plugins={[projectsPlugin]}
                opts={{
                  align: "start",
                  loop: true,
                }}
                className="w-full"
              >
                <CarouselContent className="-ml-2 md:-ml-4">
                  {projects.map((project) => (
                    <CarouselItem key={project.title} className="pl-2 md:pl-4 basis-full md:basis-1/3">
                      <ProjectCard {...project} />
                    </CarouselItem>
                  ))}
                </CarouselContent>
              </Carousel>
            </section>

            <ExpandedDialog
              isOpen={showAllProjects}
              onClose={() => setShowAllProjects(false)}
              title="All Projects"
            >
              <div className="grid gap-6 md:grid-cols-2">
                {projects.map((project) => (
                  <ProjectCard key={project.title} {...project} />
                ))}
              </div>
            </ExpandedDialog>

            <section id="skills" className="rounded-xl">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <Brain className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Expertise</h2>
              </div>
              <SkillsSection hideTitle />
            </section>

            <section id="services" className="rounded-xl">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <Wrench className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Services</h2>
              </div>
              <Services />
            </section>

            <section id="work-experience">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <Briefcase className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Work Experience</h2>
              </div>
              <WorkExperience hideTitle />
            </section>

            <section id="education">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <GraduationCap className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Education</h2>
              </div>
              <Education hideTitle />
            </section>

            <section id="certifications">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <Award className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Certifications</h2>
              </div>
              <Certifications hideTitle />
            </section>

            <section id="testimonials">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <Quote className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Testimonials</h2>
              </div>
              <Testimonials hideTitle />
            </section>

            <section id="contact">
              <div className="flex items-center gap-2 mb-8 justify-start md:justify-center">
                <MailIcon className="w-6 h-6" />
                <h2 className="text-2xl md:text-3xl font-bold">Contact</h2>
              </div>
              <ContactForm hideTitle />
            </section>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
