import { motion } from "framer-motion";
import { Award, Plus } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";
import { ExpandedDialog } from "./ui/dialog-content";
import Autoplay from "embla-carousel-autoplay";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";

const certifications = [
  {
    title: "Project Management Professional (PMP)",
    issuer: "Project Management Institute",
    date: "2021",
  },
  {
    title: "Agile Certified Practitioner",
    issuer: "PMI-ACP",
    date: "2020",
  },
  {
    title: "PRINCE2 Practitioner",
    issuer: "AXELOS",
    date: "2019",
  },
  {
    title: "Certified Scrum Master",
    issuer: "Scrum Alliance",
    date: "2019",
  },
  {
    title: "ITIL Foundation",
    issuer: "AXELOS",
    date: "2018",
  },
  {
    title: "Six Sigma Green Belt",
    issuer: "ASQ",
    date: "2018",
  },
];

interface CertificationsProps {
  hideTitle?: boolean;
}

export const Certifications = ({ hideTitle }: CertificationsProps) => {
  const [showAll, setShowAll] = useState(false);
  const plugin = Autoplay({ delay: 3000, stopOnInteraction: certifications.length <= 6 });

  return (
    <section className="py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {!hideTitle && (
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <Award className="w-6 h-6" />
              <h2 className="text-3xl font-bold">Certifications</h2>
            </div>
            <Button
              variant="outline"
              onClick={() => setShowAll(true)}
              className="gap-2"
            >
              <Plus className="w-4 h-4" /> Show All
            </Button>
          </div>
        )}
        {certifications.length <= 6 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col items-center text-center p-6 rounded-lg hover:bg-accent/5 transition-colors"
              >
                <Award className="w-8 h-8 text-primary mb-4" />
                <h3 className="text-lg font-semibold mb-2">{cert.title}</h3>
                <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                <p className="text-sm text-muted-foreground mt-2">{cert.date}</p>
              </motion.div>
            ))}
          </div>
        ) : (
          <Carousel
            plugins={[plugin]}
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent>
              {certifications.map((cert, index) => (
                <CarouselItem key={cert.title} className="basis-full sm:basis-1/2 md:basis-1/3">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="flex flex-col items-center text-center p-6 rounded-lg hover:bg-accent/5 transition-colors h-full"
                  >
                    <Award className="w-8 h-8 text-primary mb-4" />
                    <h3 className="text-lg font-semibold mb-2">{cert.title}</h3>
                    <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                    <p className="text-sm text-muted-foreground mt-2">{cert.date}</p>
                  </motion.div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        )}
      </div>

      <ExpandedDialog
        isOpen={showAll}
        onClose={() => setShowAll(false)}
        title="All Certifications"
      >
        <div className="grid gap-4">
          {certifications.map((cert) => (
            <div
              key={cert.title}
              className="flex items-center gap-4 p-4 rounded-lg hover:bg-accent/5 transition-colors"
            >
              <Award className="w-8 h-8 text-primary shrink-0" />
              <div className="flex-1">
                <h3 className="text-lg font-semibold">{cert.title}</h3>
                <p className="text-sm text-muted-foreground">{cert.issuer}</p>
              </div>
              <div className="text-sm text-muted-foreground">{cert.date}</div>
            </div>
          ))}
        </div>
      </ExpandedDialog>
    </section>
  );
};
