import { motion } from "framer-motion";
import { Briefcase } from "lucide-react";

const experiences = [
  {
    title: "Senior Project Manager",
    company: "Tech Solutions Inc.",
    companyLogo: "/company-logo-1.png",
    period: "2020 - Present",
    achievements: [
      "Led digital transformation initiatives across 5 departments",
      "Managed a team of 15 developers and designers",
      "Increased project delivery efficiency by 40%",
      "Implemented Agile methodologies across the organization"
    ]
  },
  {
    title: "Project Manager",
    company: "Innovation Labs",
    period: "2018 - 2020",
    achievements: [
      "Successfully delivered 15+ projects with focus on agile methodologies",
      "Improved project management processes by 20%",
      "Collaborated with cross-functional teams to achieve project goals"
    ]
  },
  {
    title: "Assistant Project Manager",
    company: "Digital Ventures",
    period: "2016 - 2018",
    achievements: [
      "Coordinated project resources and stakeholder communications",
      "Managed project budgets and timelines",
      "Developed project plans and schedules"
    ]
  }
];

interface WorkExperienceProps {
  hideTitle?: boolean;
}

export const WorkExperience = ({ hideTitle }: WorkExperienceProps) => {
  return (
    <section className="py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {!hideTitle && (
          <div className="flex items-center justify-center gap-2 mb-8">
            <Briefcase className="w-6 h-6" />
            <h2 className="text-3xl font-bold text-center">Work Experience</h2>
          </div>
        )}
        <div className="space-y-4">
          {experiences.map((exp, index) => (
            <motion.div
              key={exp.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="relative p-6 rounded-xl border backdrop-blur-sm group-hover:bg-accent/5 transition-colors">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    {exp.companyLogo && (
                      <img
                        src={exp.companyLogo}
                        alt={`${exp.company} logo`}
                        className="w-12 h-12 rounded-lg object-contain"
                      />
                    )}
                    <div>
                      <h3 className="text-xl font-semibold mb-1">{exp.title}</h3>
                      <p className="text-muted-foreground">{exp.company} • {exp.period}</p>
                    </div>
                  </div>
                  <div className="hidden md:block w-px h-12 bg-border" />
                  <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                    {exp.achievements.map((achievement, i) => (
                      <li key={i}>{achievement}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
