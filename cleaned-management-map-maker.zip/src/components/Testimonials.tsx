
import { useState } from "react";
import { motion } from "framer-motion";
import { Quote, Plus } from "lucide-react";
import { ExpandedDialog } from "./ui/dialog-content";
import { Button } from "./ui/button";
import Autoplay from "embla-carousel-autoplay";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";

interface Testimonial {
  name: string;
  position: string;
  company: string;
  image: string;
  text: string;
  companyLogo?: string;
}

interface TestimonialsProps {
  hideTitle?: boolean;
}

const testimonials: Testimonial[] = [
  {
    name: "Sarah Johnson",
    position: "CTO",
    company: "TechCorp",
    image: "/photo-1494790108377-be9c29b29330",
    text: "An exceptional project manager who consistently delivers results. Their leadership transformed our team's productivity and helped us achieve our goals ahead of schedule. The attention to detail and strategic thinking brought to our projects was invaluable.",
    companyLogo: "/company-logo-1.png"
  },
  {
    name: "Michael Chen",
    position: "Product Director",
    company: "InnovateLabs",
    image: "/photo-1507003211169-0a1dd7228f2d",
    text: "Outstanding ability to navigate complex projects while keeping everyone aligned and motivated. Their strategic approach and clear communication made a significant impact on our project outcomes.",
  },
  {
    name: "Emily Rodriguez",
    position: "Engineering Lead",
    company: "DevFlow",
    image: "/photo-1438761681033-6461ffad8d80",
    text: "Their strategic approach to project management has been instrumental in our success. A true professional who brings both technical expertise and leadership skills to every project.",
  },
  {
    name: "David Patel",
    position: "Senior Director",
    company: "GlobalTech Solutions",
    image: "/photo-1599566150163-29194dcaad36",
    text: "Working with this project manager was transformative for our organization. Their ability to balance technical requirements with business needs while maintaining clear communication channels was exceptional.",
  },
  {
    name: "Amanda Foster",
    position: "Operations Manager",
    company: "Innovate Hub",
    image: "/photo-1573497019940-1c28c88b4f3e",
    text: "The level of professionalism and expertise brought to our projects was outstanding. They have a unique ability to anticipate challenges and develop proactive solutions that keep projects on track.",
  },
];

export const Testimonials = ({ hideTitle }: TestimonialsProps) => {
  const [showAll, setShowAll] = useState(false);
  const [selectedTestimonial, setSelectedTestimonial] = useState<Testimonial | null>(null);
  const plugin = Autoplay({ 
    delay: 5000,
    stopOnInteraction: false,
    rootNode: (emblaRoot) => emblaRoot.parentElement,
  });

  return (
    <section id="testimonials" className="py-4 px-4 bg-accent/5">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          {!hideTitle && (
            <h2 className="text-3xl font-bold">Testimonials</h2>
          )}
          <Button
            variant="outline"
            onClick={() => setShowAll(true)}
            className="gap-2"
          >
            <Plus className="w-4 h-4" /> Show All
          </Button>
        </div>
        <div className="h-[420px]">
          <Carousel
            plugins={[plugin]}
            opts={{
              align: "start",
              loop: true,
              dragFree: true,
              skipSnaps: false,
              duration: 800,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-2 md:-ml-4">
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="pl-2 md:pl-4 basis-full md:basis-1/3">
                  <motion.div
                    initial={{ opacity: 1, y: 0 }}
                    className="bg-card border border-gray-300 p-6 rounded-xl h-full cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setSelectedTestimonial(testimonial)}
                  >
                    <Quote className="w-8 h-8 text-primary mb-4" />
                    <p className="text-muted-foreground mb-6 line-clamp-3">
                      {testimonial.text}
                    </p>
                    <div className="flex items-center gap-4 mt-auto">
                      <div className="w-12 h-12 rounded-full overflow-hidden">
                        <img
                          src={testimonial.image}
                          alt={testimonial.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-semibold">{testimonial.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {testimonial.position} at {testimonial.company}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        </div>
      </div>

      <ExpandedDialog
        isOpen={showAll}
        onClose={() => setShowAll(false)}
        title="All Testimonials"
      >
        <div className="grid gap-6 md:grid-cols-2">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.name} 
              className="p-6 rounded-xl border cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedTestimonial(testimonial)}
            >
              <Quote className="w-8 h-8 text-primary mb-4" />
              <p className="text-muted-foreground mb-6 line-clamp-3">{testimonial.text}</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.position} at {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ExpandedDialog>

      <ExpandedDialog
        isOpen={!!selectedTestimonial}
        onClose={() => setSelectedTestimonial(null)}
        title="Testimonial"
      >
        {selectedTestimonial && (
          <div className="space-y-6">
            <Quote className="w-8 h-8 text-primary" />
            <p className="text-muted-foreground">{selectedTestimonial.text}</p>
            <div className="flex items-center gap-4 pt-4 border-t">
              <div className="w-12 h-12 rounded-full overflow-hidden">
                <img
                  src={selectedTestimonial.image}
                  alt={selectedTestimonial.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h4 className="font-semibold">{selectedTestimonial.name}</h4>
                <p className="text-sm text-muted-foreground">
                  {selectedTestimonial.position} at {selectedTestimonial.company}
                </p>
              </div>
            </div>
          </div>
        )}
      </ExpandedDialog>
    </section>
  );
};
