
import { useState } from "react";
import { motion } from "framer-motion";
import { ExpandedDialog } from "./ui/dialog-content";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  image: string;
  companyLogo?: string;
  fullDescription?: string;
  projectUrl?: string;
  timeline?: string;
}

export const ProjectCard = ({ 
  title, 
  description, 
  tags, 
  image, 
  companyLogo, 
  fullDescription,
  projectUrl,
  timeline 
}: ProjectCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const images = [image, image, image]; // For demo purposes

  const truncatedDescription = description.length > 100 
    ? `${description.substring(0, 100)}...` 
    : description;

  return (
    <>
      <motion.div
        whileHover={{ y: -5 }}
        className="glass-card rounded-xl overflow-hidden cursor-pointer h-[320px]"
        onClick={() => setIsExpanded(true)}
      >
        <div className="relative h-36 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
          {companyLogo && (
            <div className="absolute top-2 right-2 w-8 h-8 rounded-full overflow-hidden bg-white">
              <img
                src={companyLogo}
                alt="Company Logo"
                className="w-full h-full object-contain"
              />
            </div>
          )}
        </div>
        <div className="p-4">
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          <p className="text-sm text-muted-foreground mb-3">{truncatedDescription}</p>
          <div className="flex flex-wrap gap-2">
            {tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 text-xs bg-secondary text-secondary-foreground rounded-full"
              >
                {tag}
              </span>
            ))}
            {tags.length > 3 && (
              <span className="px-2 py-1 text-xs bg-secondary text-secondary-foreground rounded-full">
                +{tags.length - 3}
              </span>
            )}
          </div>
        </div>
      </motion.div>

      <ExpandedDialog
        isOpen={isExpanded}
        onClose={() => setIsExpanded(false)}
        title={title}
      >
        <div className="space-y-6">
          <Carousel className="w-full">
            <CarouselContent>
              {images.map((img, index) => (
                <CarouselItem key={index}>
                  <img
                    src={img}
                    alt={`${title} - Image ${index + 1}`}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>

          {companyLogo && (
            <div className="flex items-center gap-4">
              <img
                src={companyLogo}
                alt="Company Logo"
                className="w-12 h-12 rounded-full"
              />
              {timeline && <p className="text-sm text-muted-foreground">{timeline}</p>}
            </div>
          )}

          <p className="text-muted-foreground">{fullDescription || description}</p>

          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 text-sm bg-secondary text-secondary-foreground rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>

          {projectUrl && (
            <a
              href={projectUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-4 text-primary hover:underline"
            >
              View Project →
            </a>
          )}
        </div>
      </ExpandedDialog>
    </>
  );
};
