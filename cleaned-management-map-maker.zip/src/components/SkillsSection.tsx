
import { motion } from "framer-motion";
import { Briefcase, Users, Target, LineChart, ShieldCheck, Brain, Plus } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";
import { ExpandedDialog } from "./ui/dialog-content";
import Autoplay from "embla-carousel-autoplay";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";

interface SkillsSectionProps {
  hideTitle?: boolean;
}

const skills = [
  { name: "Project Management", icon: Briefcase },
  { name: "Team Leadership", icon: Users },
  { name: "Strategic Planning", icon: Target },
  { name: "Risk Management", icon: ShieldCheck },
  { name: "Performance Analysis", icon: LineChart },
  { name: "Problem Solving", icon: Brain },
];

export const SkillsSection = ({ hideTitle }: SkillsSectionProps) => {
  const [showAll, setShowAll] = useState(false);
  const plugin = Autoplay({ delay: 2000, stopOnInteraction: false });

  return (
    <section id="skills" className="py-12 px-4 bg-accent/5">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-12">
          {!hideTitle && (
            <h2 className="text-3xl font-bold">Expertise</h2>
          )}
          <Button
            variant="outline"
            onClick={() => setShowAll(true)}
            className="gap-2"
          >
            <Plus className="w-4 h-4" /> Show All
          </Button>
        </div>
        <Carousel
          plugins={[plugin]}
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent className="-ml-2 md:-ml-4">
            {skills.map((skill, index) => (
              <CarouselItem key={skill.name} className="pl-2 md:pl-4 basis-1/2 md:basis-1/5">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex flex-col items-center text-center p-6"
                >
                  <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                    {<skill.icon className="w-8 h-8 text-primary" />}
                  </div>
                  <h3 className="font-medium">{skill.name}</h3>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
      </div>

      <ExpandedDialog
        isOpen={showAll}
        onClose={() => setShowAll(false)}
        title="All Expertise"
      >
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {skills.map((skill) => (
            <div
              key={skill.name}
              className="flex flex-col items-center text-center p-4"
            >
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                {<skill.icon className="w-8 h-8 text-primary" />}
              </div>
              <h3 className="font-medium">{skill.name}</h3>
            </div>
          ))}
        </div>
      </ExpandedDialog>
    </section>
  );
};
